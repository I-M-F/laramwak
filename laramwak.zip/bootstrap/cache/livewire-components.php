<?php return array (
  'member-registartion-form' => 'App\\Http\\Livewire\\MemberRegistartionForm',
);